package Kiosk;

import Common.Cw;

public class Kiosk {
	void run() {
		
		
		Disp.title();
		
		loop_a:
		while(true) {
			Cw.wn("명령 : [ 1.음료 // 2.디저트 // 3.굿즈 // e.종료 ]");
			KioskObj.cmd = KioskObj.sc.next();
			switch(KioskObj.cmd){
			case "1":
			case "음료":
				Cw.wn("음료 코너로 진입합니다");
				ProcMenuDrink.run();
				break;
			case "2":
			case "디저트":
				
				ProcMenuDessert.run();
				
				break;
				
			case "3":
			case "굿즈":
				ProcMenuFigure.run();
				break;
				
			case "e":
			case "종료":
				Cw.wn("==========================");
				for(Order o: KioskObj.basket) {
					Cw.wn(o.selectedProduct.name);
				}
				Cw.wn("==========================");
				
				Cw.wn("장바구니에 담긴 물건 갯수 : " + KioskObj.basket.size());
				int sum = 0;
				for(Order p : KioskObj.basket) {
					sum += p.selectedProduct.price;
					
				}
				Cw.wn("총 음료의 가격은 " + sum + "원 입니다" );
				break loop_a;
				
				
			}
			
			
		}
		
		Cw.wn("주문이 완료되었습니다");
		
	}

}
