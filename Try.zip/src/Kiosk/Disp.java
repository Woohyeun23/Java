package Kiosk;

import Common.Cw;

public class Disp {
	
	final static String dot = "★";
	final static int dot_count = 38;
	
	
	public static void line() {
		for(int i = 0; i < dot_count; i++) {
		Cw.w(dot);
		}
		Cw.wn("");
	}

	public static void dot(int n) {
		for(int i = 0; i < n; i++) {
			Cw.w(dot);
		}
		
	}
	
	
	public static void title() {
		line();
		dot(10);
		Cw.w("*****고양이 카페*****");
		dot(10);
		Cw.wn("");
		line();
		
	}
	
	
}
