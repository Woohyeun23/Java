package Kiosk;

import Common.Cw;
import Product.Figure;
import Product.Product;

public class ProcMenuFigure {
	
	//ctrl + H --> 함수 쓰인곳을 검색
	public static void run() {
//		KioskObj.ProductClear();
//		KioskObj.ProductFigure();
//		Cw.wn("지금 부터 굿즈 페이지로 이동합니다");
//		Cw.wn("");
//		for(Product r : KioskObj.Products) {
//			Cw.wn(r.name +""+r.price+"원");
//		}
//		
		
		KioskObj.ProductAll();
		for(Product p : KioskObj.Products) {
			if(p instanceof Figure) {
				Cw.wn(p.name+""+ p.price + "원");
			}
		}
		
		loop_f :
			while(true) {
				Cw.wn("[ 1. 미니 애옹이(미애) // 2. 손을 올린 애옹이(소내) // x.이전 메뉴]");
				KioskObj.cmd = KioskObj.sc.next();
				
				switch(KioskObj.cmd) {
				case "1":
				case "미애":
					Cw.wn("커여운 " +KioskObj.Products.get(0).name + "한 마리 나갑니다");
					KioskObj.basket.add(new Order(KioskObj.Products.get(0)));
					break;
					
				case "2":
				case "소내":
					Cw.wn("심장을 울리는 "+ KioskObj.Products.get(1).name + "한 마리 겟또다제~");
					Order n = new Order(KioskObj.Products.get(1));
					KioskObj.basket.add(n);
					break;
					
				case "x":
					Cw.wn("이전 메뉴로 돌아갑니다");
					break loop_f;
					
					default :
						Cw.wn("그런 물건은 취급하지 않습니다");
				}
				
				
			}
			
		
	}

}
