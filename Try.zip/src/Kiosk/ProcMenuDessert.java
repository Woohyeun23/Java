package Kiosk;

import Common.Cw;
import Product.Dessert;
import Product.Product;

public class ProcMenuDessert {
	public static void run() {
//		KioskObj.ProductClear();
//		KioskObj.ProductDessert();
//			Cw.wn("디저트 메뉴입니다");
//		for(Product o: KioskObj.Products) {
//			Cw.wn(o.name + "" + o.price + "원");
//		}
		Cw.wn("디저트 메뉴입니다");
		KioskObj.ProductAll();
		for(Product p : KioskObj.Products) {
			if(p instanceof Dessert) {
				Cw.wn(p.name + "" + p.price + "원");
			}
		}
		
	
		
		loop_d :
			while(true) {
				Cw.wn("[ 1.뚱카롱 // 2. 몽블랑 // x.이전메뉴 ]");
				KioskObj.cmd = KioskObj.sc.next();
				switch(KioskObj.cmd) {
				case "1":
				case "뚱카롱":
					Cw.wn(KioskObj.Products.get(0).name + "하나 들어갑니다~");
					Order n = new Order(KioskObj.Products.get(0));
					KioskObj.basket.add(n);
//					KioskObj.basket.add(new Order(KioskObj.Products.get(0)));
					
					break;
					
				case "2":
				case "몽블랑":
					Cw.wn("달콤하고 크리미한 "+KioskObj.Products.get(1).name + "하나 들어갑니다~");
//					Order n1 = new Order(KioskObj.Products.get(1));
//					KioskObj.basket.add(n1);
					KioskObj.basket.add(new Order(KioskObj.Products.get(1)));
					
					break;
					
				case "x":
					Cw.wn("이전 메뉴로 돌아갑니다");
					 break loop_d;
					 
				default: 
					Cw.wn("그런 상품은 없습니다");
						 
				
					
				}
				
			}
		
		
		
		
		
		
		
		
		
		
	}
}
