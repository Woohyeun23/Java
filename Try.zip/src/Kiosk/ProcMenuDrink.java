package Kiosk;

import Common.Cw;
import Product.Drink;
import Product.Product;

public class ProcMenuDrink {
	
	public static void run() {
//		KioskObj.ProductClear();
//		KioskObj.ProductDrink();
//		Cw.wn("음료 메뉴에 진입 합니다");
//		for(Product p: KioskObj.Products) {
//			Cw.wn(p.name + " " + p.price+" 원");
//			}
		
		Cw.wn("음료 메뉴에 진입 합니다");
		KioskObj.ProductAll();
		for(Product p : KioskObj.Products) {
			if(p instanceof Drink) {
				Cw.wn(p.name + "" + p.price + "원");
			}
		}

		Cw.wn("");
		Cw.wn("지금부터 주문을 받곘습니다");
			loop_b : 
				while(true) {
					Cw.wn("[ 1.커피 // 2.오랜지쥬스 // x.이전메뉴 ]");
					KioskObj.cmd = KioskObj.sc.next();
					switch(KioskObj.cmd) {
					case "1":
					case "커피":
						ProcDrinkHotCold.run();
						break;
					case "2":
					case "오랜지쥬스":
						Cw.wn(KioskObj.Products.get(1).name + "하나 드갑니다아아아아!");
						KioskObj.basket.add(new Order(KioskObj.Products.get(1)));
						Cw.wn("다음 음료를 골라주세요");
						break;
						
						
					case "x":
					case "이전메뉴":
						Cw.wn("");
						Cw.wn("이전 메뉴로 이동합니다");
						break loop_b;
					default :
						Cw.wn("다시 입력하라");
					}
					
					
					
				}
		
		
		
}
}