package Kiosk;

import java.util.ArrayList;
import java.util.Scanner;

import Product.Dessert;
import Product.Drink;
import Product.Figure;
import Product.Product;

public class KioskObj {
	public static Scanner sc = new Scanner(System.in);
	public static ArrayList<Product> Products = new ArrayList<Product>();
	public static ArrayList<Order> basket = new ArrayList<Order>();
	public static String cmd;
	
	
	
	public static void ProductAll() {
		Products.add(new Drink("커피", 1000));
		Products.add(new Drink("오랜지 쥬스", 2000));
		Products.add(new Dessert("뚱카롱" , 5000));
		Products.add(new Dessert("몽블랑" , 7000));
		Products.add(new Figure("미니 애옹이" , 10000));
		Products.add(new Figure("손을 올린 애옹이" , 15000));
	}
	
	
	
	
	
	
	public static void ProductDrink() {
		
		Products.add(new Drink("커피", 1000));
		Products.add(new Drink("오랜지 쥬스", 2000));
	}
	
	public static void  ProductDessert() {
		Products.add(new Dessert("뚱카롱" , 5000));
		Products.add(new Dessert("몽블랑" , 7000));
	}
	
	public static void ProductFigure() {
		Products.add(new Figure("미니 애옹이" , 10000));
		Products.add(new Figure("손을 올린 애옹이" , 15000));
	}
	
	public static void ProductClear() {
		Products.clear();
	}
	

}
