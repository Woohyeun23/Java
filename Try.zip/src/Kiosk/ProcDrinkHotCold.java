package Kiosk;

import Common.Cw;

public class ProcDrinkHotCold {

	
	public static void run() {
		loop_c :
		while(true) {
			Cw.wn("[ 1.아이스 아메리카노(아아) // 2.뜨거운 아메리카노(뜨아) // x.이전 메뉴]");
			KioskObj.cmd = KioskObj.sc.next();
			switch(KioskObj.cmd) {
			case "1":
			case "아아":
				Cw.wn("씨워어어어언한 아이스아메리카노 하나 나갑니다아아아아앙");
				KioskObj.basket.add(new Order(KioskObj.Products.get(0),1));
				break loop_c;
				
			case "2":
			case "뜨아":
				Cw.wn("제 마음처럼 뜨겁디 뜨거운 핫! 아메리카노 하나 나갑니다아아아아앙");
				KioskObj.basket.add(new Order(KioskObj.Products.get(0),2));
				
				break loop_c;
			case "이전메뉴":
			case "x":
				Cw.wn("이전 메뉴 이동");
				break loop_c;
			
			default : 
				Cw.wn("그런 상품은 없습니다");
			}
		}
	}
}
