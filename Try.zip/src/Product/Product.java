package Product;

public class Product {
	public String name;
	public int price;
	
//	Product(String name, int price){
//		this.name = name;
//		this.price = price;
//		
//	}
//	
	Product(String xx, int yy){
		name = xx;
		price = yy;
	}

	

	
}
