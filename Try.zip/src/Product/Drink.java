package Product;

public class Drink extends Product {

	public Drink(String xx, int yy) {
		super(xx, yy);
	}
}
