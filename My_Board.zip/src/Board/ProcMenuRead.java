package Board;

import Serve.Data;
import Serve.Post;
import Utill.Ci;
import Utill.Cw;

public class ProcMenuRead {
	static void run() {
		Cw.wn("읽기 기능을 실행합니다 [ x :  뒤로 가기]");
		Cw.wn("");
		
		
		
//		
//		String cmd = Ci.r("읽을 글 번호");
//		for(Post p: Data.posts) {
//			if(cmd.equals(p.instanceNo+"")) {
//				p.infoForRead();
//				break;
//			} else {
//				Cw.wn("다시 입력해주세요");
//			}
//			
//		}
//		
		
		
		boolean fact = false;
			
		while(!fact) {
		String cmd = Ci.r("읽을 글 번호");
		
		for(Post p: Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {
				p.infoForRead();
				fact = true;
				break;
			} 
			
		}
		
		if(cmd.equals("x")) {
			Cw.wn("");
			Cw.wn("이전 메뉴로 돌아갑니다");
			Cw.wn("");
			fact = true;
			break;
		}
		
		
		if (!fact) {
			Cw.wn("유효하지 않은 번호입니다");
			Cw.wn("");
		}
		}
		
		
		
			
			
			
		

			
	}
}
