package Board;

import Serve.Data;
import Serve.Post;
import Utill.Ci;
import Utill.Cw;

public class ProcMenuWrite {
	static void run() {
		Cw.wn("지금 부터 글을 작성 해주세요");
		
		String title;
		while(true) {
		title = Ci.r("글제목");	
		if(title.length()>0) {
			Cw.wn("");
			break;
		} else {
			Cw.wn("글자수가 부족합니다");
			
		}
		}
		
		String content;
		while(true) {
			content = Ci.rl("글내용");
			if(content.length()>5) {
				Cw.wn("");
				break;
			} else {
				Cw.wn("게시물의 내용이 부족합니다");
			}
		}
		
		
		String writer;
		while(true) {
			writer = Ci.r("작성자");
			if(writer.length()> 0) {
				Cw.wn("");
				break;
			} else if(writer.length()>10) {
				Cw.wn("이름이 너무 깁니다");
			} else {
				Cw.wn("이름을 입력하지 않았습니다");
			}
		}
		
		
		Post p = new Post(title, content, writer, 0);
			Data.posts.add(p);
			Cw.wn("");
			Cw.wn("글이 작성되었습니다");
		
		}
		
		
		
		
		
	}

