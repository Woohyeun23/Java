package Board;

import Serve.Data;
import Serve.Post;
import Utill.Ci;
import Utill.Cw;

public class ProcMenuUpdate {
	static void run() {
		Cw.wn("글수정 시스템을 실행합니다");
		
		boolean factUp = false;
		while(!factUp) {
			
		String cmd = Ci.r("수정할 글 번호를 입력해주세요");
			
		for(Post p:Data.posts) {
			String content = Ci.rl("수정할 내용");
			
			if(cmd.equals(p.instanceNo+"")) {
				p.content = content;
				Cw.wn("");
				Cw.wn("해당 번호의 글이 수정 되었습니다");
				factUp = true;
				break;
			}
			
		}
		if(cmd.equals("x")) {
			Cw.wn("");
			Cw.wn("이전 메뉴로 돌아갑니다");
			Cw.wn("");
			factUp = true;
			break;
		}
		
		if(!factUp) {
			Cw.wn("");
			Cw.wn("해당 번호의 글은 존재하지 않습니다");
			Cw.wn("");
	
		}
	  }
		
		
	}
}
