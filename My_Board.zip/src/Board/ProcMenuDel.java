package Board;

import Serve.Data;
import Serve.Post;
import Utill.Ci;
import Utill.Cw;

public class ProcMenuDel {
	static void run() {
		Cw.wn("삭제 기능을 실행합니다 [ x : 뒤로 가기 ]");
		boolean factDel = false;
		int tempSearchIndex = 0;
		
		while(!factDel) {
		
		String cmd = Ci.r("삭제할 번호를 입력해주세요");
		
		for(int i= 0; i < Data.posts.size(); i++) {
			if(cmd.equals(Data.posts.get(i).instanceNo+"")) {
				tempSearchIndex = i;
				factDel = true;
				Cw.wn("");
				Cw.wn("글 "+Data.posts.get(tempSearchIndex).instanceNo+"번을 삭제했습니다");
				
				for(int l = i+1; l < Data.posts.size(); l++) {
					Data.posts.get(l).instanceNo -= 1; // --로 같은 의미
				}
				Data.posts.remove(tempSearchIndex);
				
				break;
			}
		}
		if(cmd.equals("x")) {
			Cw.wn("");
			Cw.wn("이전 메뉴로 돌아갑니다");
			Cw.wn(""); 
			break;
		}
		
		if(!factDel) {
			Cw.wn("");
			Cw.wn("그런 번호의 글은 존재하지 않습니다");
			Cw.wn("");
		}
		}
		
		for(Post d : Data.posts) {
			Cw.wn("번호는 "+d.no + "와 " + d.instanceNo+ "다");
		}
		
		Cw.wn("");
		Cw.wn("현재 남은 글 수 :" +Data.posts.size());
		Cw.wn("");
		
	}
}
